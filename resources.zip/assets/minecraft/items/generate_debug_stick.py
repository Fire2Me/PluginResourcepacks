packs = [
    "plain",
    "crop",
    "cave",
    "brine",
    "split",
    "shade",
    "hot",
    "end"]

with open("debug_stick.json", "w") as f_out:
    f_out.write("""{
  "model": {
    "type": "minecraft:select",
    "property": "minecraft:component",
    "component": "minecraft:custom_data",
    "cases": [""")
    
    for pack in packs:
        f_out.write(f"""{{
  "when": "{{tag:\\"pack\\", type:\\"{pack.title()}\\"}}",
  "model": {{
    "type": "minecraft:model",
    "model": "minecraft:item/pack_{pack}"
  }}
}},""")
        
    f_out.write(f"""{{
  "when": "{{tag:\\"deck\\"}}",
  "model": {{
    "type": "minecraft:model",
    "model": "minecraft:item/deck"
  }}
}},""")
    
    
    f_out.write("""],
    "fallback": {
      "type": "minecraft:model",
      "model": "minecraft:item/card"
    }
  }
}""")
