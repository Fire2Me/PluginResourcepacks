packs = [
    "plain",
    "crop",
    "cave",
    "brine",
    "split",
    "shade",
    "hot",
    "end"]

for pack in packs:
    with open(f"pack_{pack}.json", "w") as f_out:
        f_out.write(f"""{{
  "parent": "minecraft:item/generated",
  "textures": {{
    "layer0": "minecraft:item/pack_{pack}"
  }},
  "render": {{
    "glint": false
  }},
  "display": {{
    "firstperson_righthand": {{
      "rotation": [0, 0, 0],
      "translation": [0, 4, -3],
      "scale": [0.7, 0.7, 0.7]
    }},
    "firstperson_lefthand": {{
      "rotation": [0, 0, 0],
      "translation": [0, 4, -3],
      "scale": [0.7, 0.7, 0.7]
    }},
    "thirdperson_righthand": {{
      "rotation": [0, 0, 0],
      "translation": [0, 3, 1],
      "scale": [0.4, 0.4, 0.4]
    }},
    "thirdperson_lefthand": {{
      "rotation": [0, 0, 0],
      "translation": [0, 3, -1],
      "scale": [0.4, 0.4, 0.4]
    }}
  }}
}}""")

        
    